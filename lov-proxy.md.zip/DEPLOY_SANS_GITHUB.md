# 🚀 Déployer le Proxy SANS GitHub

## ✅ Solution : Dossier Standalone Créé

J'ai créé un dossier `proxy-standalone/` avec tout le nécessaire pour déployer le proxy indépendamment.

## 📦 Contenu du Dossier

```
proxy-standalone/
├── server.js       # Serveur proxy
├── package.json    # Dépendances
├── render.yaml     # Config Render
└── README.md       # Documentation
```

## 🎯 Méthode Simple : Render avec ZIP

### Étape 1 : Créer le ZIP

1. **Va dans le dossier** `proxy-standalone/`
2. **Sélectionne les fichiers** :
   - `server.js`
   - `package.json`
   - `render.yaml`
3. **Crée une archive ZIP** (clic droit → Compresser)
4. **Nomme-la** : `lov-proxy.zip`

### Étape 2 : Déployer sur Render

1. **Va sur** : https://render.com

2. **Crée un compte** (gratuit, avec email)

3. **Dashboard** → **New** → **Web Service**

4. **Choisis une option** :
   
   **Option A : Blueprint (Plus Simple)**
   - Clique sur **"Use a Blueprint"**
   - Upload `render.yaml`
   - Render configure tout automatiquement

   **Option B : Configuration Manuelle**
   - **Build Command** : `npm install`
   - **Start Command** : `npm start`
   - **Environment** : `Node`

5. **Ajoute la variable d'environnement** :
   - Clique sur **"Environment"**
   - Ajoute :
     ```
     Key: OPENAI_API_KEY
     Value: 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
     ```

6. **Clique sur "Create Web Service"**

7. **Attends 2-3 minutes** (Render installe et démarre)

8. **Copie l'URL** en haut de la page (ex: `https://lov-openai-proxy.onrender.com`)

### Étape 3 : Configurer Netlify

1. **Va sur** : https://app.netlify.com

2. **Sélectionne ton site** LoV

3. **Site settings** → **Environment variables**

4. **Add a variable** :
   ```
   Key: VITE_OPENAI_PROXY_URL
   Value: https://lov-openai-proxy.onrender.com/api/openai
   ```
   (Remplace par ton URL Render)

5. **Save**

### Étape 4 : Redéployer Netlify

1. **Deploys** → **Trigger deploy** → **Deploy site**

2. **Attends 2-3 minutes**

3. **Teste** sur https://keen-tiramisu-104b8a.netlify.app/

## 🎯 Alternative : Glitch (Encore Plus Simple)

Si Render ne marche pas, essaie Glitch :

1. **Va sur** : https://glitch.com

2. **New Project** → **Import from GitHub**
   
   Ou **Upload** le ZIP

3. **Ajoute dans `.env`** :
   ```
   OPENAI_API_KEY=ta-clé-ici
   ```

4. **Copie l'URL** (ex: `https://lov-proxy.glitch.me`)

5. **Utilise dans Netlify** :
   ```
   VITE_OPENAI_PROXY_URL=https://lov-proxy.glitch.me/api/openai
   ```

## 🧪 Tester le Proxy

Une fois déployé, ouvre dans ton navigateur :

```
https://ton-url-render.onrender.com/health
```

Tu devrais voir :
```json
{"status":"ok","timestamp":"2025-10-23T..."}
```

✅ Si tu vois ça, le proxy fonctionne !

## 📋 Checklist Complète

- [ ] Dossier `proxy-standalone/` créé
- [ ] ZIP créé avec les fichiers
- [ ] Compte Render créé
- [ ] Service créé sur Render
- [ ] Variable `OPENAI_API_KEY` configurée sur Render
- [ ] Service déployé (statut "Live")
- [ ] URL du proxy copiée
- [ ] Variable `VITE_OPENAI_PROXY_URL` ajoutée dans Netlify
- [ ] Netlify redéployé
- [ ] Health check testé
- [ ] Fonctionnalités IA testées

## 💡 Avantages de Cette Méthode

- ✅ **Pas besoin de GitHub** pour le proxy
- ✅ **Gratuit** (Render Free Tier)
- ✅ **Simple** (juste un ZIP)
- ✅ **Rapide** (5 minutes)
- ✅ **Sécurisé** (clé API sur le serveur)

## 🔒 Sécurité

Le proxy est configuré pour accepter uniquement :
- `https://keen-tiramisu-104b8a.netlify.app`
- `http://localhost:5575` (pour le dev)

Personne d'autre ne peut l'utiliser !

## 💰 Coût

**Render Free Tier** :
- 750 heures/mois gratuit
- Largement suffisant pour commencer
- Pas de carte bancaire requise

## 🎉 Résultat

Après ces étapes :
- ✅ Le proxy est déployé publiquement
- ✅ Toutes les fonctionnalités IA marchent pour tous
- ✅ Pas besoin de GitHub
- ✅ Pas besoin de lancer le serveur en local

**Ton application LoV sera 100% fonctionnelle en production !** 🚀

## 🐛 Besoin d'Aide ?

Si tu as un problème :
1. Vérifie les logs sur Render
2. Teste le health check
3. Vérifie que la variable `OPENAI_API_KEY` est bien configurée
4. Vérifie que l'URL dans Netlify est correcte

Tout est dans le dossier `proxy-standalone/` !
